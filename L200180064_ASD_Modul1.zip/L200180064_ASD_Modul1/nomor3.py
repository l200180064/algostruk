def jumlahHurufVokal(input):
    total = 0
    voc = ["a", "i", "u", "e", "o"]
    for A in input:
        if A in voc:
            total+=1
    return [len(input), total]

def jumlahHurufKonsonan(input):
    total = 0
    voc = ["a", "i", "u", "e", "o"]
    for A in input:
        if A in voc:
            total+=1
    return [len(input), len(input)-total]

v = jumlahHurufVokal("Surakarta")
k = jumlahHurufKonsonan("Surakarta")

print(v)
print(k)