def selesaikanABC(a,b,c):
    a=float(a)
    b=float(b)
    c=float(c)
    D=(b**2)-(4*a*c)
    if D<0:
        return "determinan negatif"
    return  "determinan positif"

""" 
Jadi gini karina muslimah :) 
Kalo kamu abis ngerun suatu file [ctrl + alt + N] itu kalo mau ngerun file yg lain dimatiin dulu compiler yg
sebelumnya [Alt + Alt + M] atau klik kanan di terminal nya teru

"""