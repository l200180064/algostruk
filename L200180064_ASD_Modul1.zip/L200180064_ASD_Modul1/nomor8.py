def apakahTerkandung(a,b):
    return a in b
print(apakahTerkandung("db","abcdcdsqwedb"))
print(apakahTerkandung("abd","abc"))