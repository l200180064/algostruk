#Praktikum Algoritma dan Struktur Data
#Modul 4
#Nama   : Dzaki Fadhlurrohman
#NIM    : L200180064


#Halaman 40
##def cariLurus(wadah, target):
##    n = len(wadah)
##    for i in range (n):
##        if wadah[i] == target:
##            return True
##    return False



###Halaman 41
##class MhsTIF(object):
##    """Class Mahasiswa yang dibangun dari class Manusia."""
##    def __init__(self,nama,NIM,kota,us):
##        """Metode inisiasi ini menutupi metode inisiasi di class Manusia."""
##        self.nama = nama
##        self.NIM = NIM
##        self.kotaTinggal = kota
##        self.uangSaku = us
##    def __str__(self):
##        s = self.nama + ', NIM ' + str(self.NIM) \
##            + '. Tinggal di ' + self.kotaTinggal \
##            + '. Uang saku Rp ' + str(self.uangSaku) \
##            + ' tiap bulannya.'
##        return s
##    def ambilNama(self):
##        return self.nama
##    def ambilNIM(self):
##        return self.NIM
##    def ambilUangSaku(self):
##        return self.uangSaku
##    def makan(self,s):
##        """Metode ini menutupi metode 'makan'-nya class Manusia.
##        Mahasiswa kalau makan sambil belajar."""
##        print("Saya baru saja makan",s,"sambil belajar.")
##        self.keadaan = 'kenyang'
##
##   
##c0 = MhsTIF('Ika',10,'Sukoharjo',240000)
##c1 = MhsTIF('Budi',51,'Sragen',230000)
##c2 = MhsTIF('Ahmad',2,'Surakarta',250000)
##c3 = MhsTIF('Chandra',18,'Surakarta',235000)
##c4 = MhsTIF('Eka',4,'Boyolali',240000)
##c5 = MhsTIF('Fandi',31,'Salatiga',250000)
##c6 = MhsTIF('Deni',13,'Klaten',245000)
##c7 = MhsTIF('Galuh',5,'Wonogiri',245000)
##c8 = MhsTIF('Janto',23,'Klaten',245000)
##c9 = MhsTIF('Hasan',64,'Karanganyar',270000)
##c10 = MhsTIF('Khalid',29,'Purwodadi',265000)
##
###Lalu kita membuat daftar mahasiswa dalam bentuk list seperti ini:
##
##Daftar = [c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10]
##
####target = 'Klaten'
####for i in Daftar:
####    if i.kotaTinggal == target:
####        print(i.nama + ' tinggal di ' + target)
##
##
##
###Halaman 42
##kumpulan = [1,2,3,4,5,0]
##
##def cariTerkecil(kumpulan):
##    n = len(kumpulan)
##    #Anggap item pertama adalah yang terkecil
##    terkecil = kumpulan[0]
##    #Tentukan apakah item lain lebih kecil
##    for i in range(1,n):
##        if kumpulan[i] < terkecil:
##            terkecil = kumpulan[i]
##
##    return terkecil     #Kembalikan yang terkecil
##print(cariTerkecil(kumpulan))
##
##
##
##Bagaimana programnya jika kita ingin mencari mahasiswa(dari class MhsTIF di atas) yang uang sakunya terkecil
##def kecil(Daftar):
##    minim = Daftar[0].uangSaku
##    for i in Daftar:
##        if i.uangSaku < minim:
##            minim = i.uangSaku
##            if i.uangSaku == minim:
##                nama = i.nama
##    return nama, minim
##print(kecil(Daftar))
##
##
##Bagaimana jika yang terbesar
##def besar(Daftar):
##    maxim = Daftar[0].uangSaku
##    for i in Daftar:
##        if i.uangSaku > maxim:
##            maxim = i.uangSaku
##            if i.uangSaku == maxim:
##                nama = i.nama
##    return nama, maxim
##print(besar(Daftar))
##
##
##Bagaimanakah programnya jika kita ingin mencari semua mahasiswa yang uang sakunya kurang dari 250 ribu
##def kurang(Daftar):
##    a=[]
##    for i in Daftar:
##        if i.uangSaku < 250000:
##            a.append(i.nama)
##    return a
##print(kurang(Daftar))
##
##
##Yang lebih dari 250 ribu
##def lebih(Daftar):
##    a = []
##    for i in Daftar:
##        if i.uangSaku >= 250000:
##            a.append(i.nama)
##    return a
##print(lebih(Daftar))



#Halaman 43
##def binSe(list, terget):
##    #mulai dari seluruh runtutan elemen
##    low = 0
##    high = len(list) - 1
##
##    #secara berulang belah runtutan itu menjadi separuhnya
##    #   sampai targetnya ditemukan
##    while low <= high:
##            #temukan pertengahan runtut itu
##        mid = (high + low) // 2
##            #Apakah pertengahanya semua target?
##        if list[mid] == target:
##            return True
##            #ataukah targetnya di sebelah kirinya?
##        elif target < list[mid]:
##            high = mid - 1
##            #atau targetnya ada di sebelah kananya?
##        else:
##            low = mid + 1
##        #jika runtutnya tidak bisa dibelah lagi, berarti targetnya tidak ada
##    return False
##
##
##list = [2,3,5,6,6,6,8,9,9,10,11,12,13,13,14]
##target = 6
##print(binSe(list,target))
##list = [2,3,5,6,6,6,8,9,9,10,11,12,13,13,14]
##target = 7
##print(binSe(list,target))



####Dapatkah kamu mengubah programnya agar dia mengembalikan index-nya kalau targetnya ditemukan,
####dan mengembalikan False kalau target tidak ditemukan
##
##def binSe(list, target):
##    a=[]
##    low = 0
##    high = len(list) - 1
##    while(low<=high):
##        mid = (low+high)//2l200
##        if(list[mid] == target):
##            a.append(list.index(target))
##            i=list.index(target)-1
##            j = list.index(target) + 1
##            while target == list[i]:
##                a.append(i)
##                i-=1
##            while target == list[j]:
##                a.append(j)
##                j+=1
##            return a
##        elif(target<list[mid]):
##            high = mid - 1
##        else:
##            low = mid + 1
##    return False
##
##
##list = [2,3,3,3,4,4,4,4,4,5,6,6,8,9,9,10,11,12,13,13,14]
##target = 6
##print(binSe(list,target))
##list = [2,3,5,6,6,6,8,9,9,10,11,12,13,13,14]
##target = 7
##print(binSe(list,target))
l200